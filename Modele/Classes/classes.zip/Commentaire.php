<?php

/**
 * Created by PhpStorm.
 * User: Jordan
 * Date: 27/09/2015
 * Time: 16:15
 */
class Commentaire
{
    private $id;
    private $txt;

    /**
     * Commentaire constructor.
     * @param $id
     * @param $txt
     */
    public function __construct($id, $txt)
    {
        $this->id = $id;
        $this->txt = $txt;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getTxt()
    {
        return $this->txt;
    }

    /**
     * @param mixed $txt
     */
    public function setTxt($txt)
    {
        $this->txt = $txt;
    }


}