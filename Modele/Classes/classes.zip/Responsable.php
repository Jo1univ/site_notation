<?php

/**
 * Created by PhpStorm.
 * User: Jordan
 * Date: 27/09/2015
 * Time: 16:24
 */
class Responsable extends Personne
{

    /**
     * Responsable constructor.
     */
    public function __construct()
    {
    }
}